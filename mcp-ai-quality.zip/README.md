# MCP AI Quality Server

This environment supports AI detection, false literature test, and humanization/fact correction.